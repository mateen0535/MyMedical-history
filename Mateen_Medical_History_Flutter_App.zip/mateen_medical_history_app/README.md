# My Medical History — Muhammad Mateen

A mobile-friendly Flutter app based on your uploaded **My Medical History / Clinical Clarity** GUI.

## Screens included
- Dashboard personalized with **Muhammad Mateen**
- Medical timeline with search and category filters
- Add medical record dialog
- Medications screen
- Documents screen
- Bottom navigation designed for Android phones

## Open and run in VS Code (Windows)
1. Install the Flutter SDK and Android Studio, then configure Flutter in your PATH.
2. Extract this ZIP and open the `mateen_medical_history_app` folder in VS Code.
3. Open **Terminal → New Terminal** and run these commands:
   ```powershell
   flutter doctor
   flutter create . --platforms=android
   flutter pub get
   flutter run
   ```
   The `flutter create` step ensures your local Flutter installation generates the matching Android Gradle wrapper and platform boilerplate. It does not replace `lib/main.dart`.
4. For a real Android phone, enable **Developer options → USB debugging**, connect by USB, accept the phone's debugging prompt, then run `flutter devices` followed by `flutter run`.

## Build an Android APK
```powershell
flutter build apk --release
```
The APK is normally created at `build\app\outputs\flutter-apk\app-release.apk`.

## Important notes
- The app uses Flutter's built-in Material widgets and has no third-party runtime dependencies.
- The records are sample data. Records added in the dialog remain while the app is open; they are not saved after the app is closed. Local database/Firebase persistence can be added next.
- The medication information is demo content, not medical advice.
- The three PNGs in `screenshots/` are mobile-sized UI previews of the app design. They were not captured from a running Android emulator in this workspace because the Flutter SDK/emulator is not installed here.
