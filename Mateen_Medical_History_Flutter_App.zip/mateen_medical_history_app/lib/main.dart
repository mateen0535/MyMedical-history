import 'package:flutter/material.dart';

void main() => runApp(const MedicalHistoryApp());

const navy = Color(0xFF131B2E);
const primaryBlue = Color(0xFF006194);
const canvas = Color(0xFFFAF8FF);
const paleBlue = Color(0xFFF0F2FF);
const borderColor = Color(0xFFE2E7F0);
const muted = Color(0xFF64748B);
const mint = Color(0xFF10B981);

class MedicalHistoryApp extends StatelessWidget {
  const MedicalHistoryApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Medical History',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(seedColor: primaryBlue, brightness: Brightness.light),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: navy, elevation: 0),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: borderColor)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: borderColor)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: primaryBlue, width: 1.5)),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

class MedicalRecord {
  MedicalRecord({required this.title, required this.category, required this.date, required this.provider, this.detail = '', this.status = ''});
  final String title, category, date, provider, detail, status;
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 1;
  String filter = 'All';
  String query = '';
  final searchController = TextEditingController();
  final List<MedicalRecord> records = [
    MedicalRecord(title: 'Routine Cardiology Follow-up', category: 'Visits', date: 'Oct 18, 2024', provider: 'Dr. Sarah Jenkins · St. Jude Medical Center', detail: 'Diagnosis: Mild Hypertension · BP: 122/80 mmHg', status: 'Controlled'),
    MedicalRecord(title: 'Annual Influenza Vaccine', category: 'Vaccines', date: 'Aug 04, 2024', provider: 'Walgreens Pharmacy Clinic', detail: 'Batch: FL-9021 · Intramuscular (Deltoid)', status: 'Up to date'),
    MedicalRecord(title: 'Dermatology Skin Screening', category: 'Visits', date: 'May 12, 2024', provider: 'Dr. Leo Vance · Vance Dermatological Center', detail: 'Result: Benign nevi detected, baseline photos updated.', status: ''),
    MedicalRecord(title: 'Laparoscopic Appendectomy', category: 'Surgeries', date: 'Nov 20, 2023', provider: 'Memorial Hospital · Dr. Robert Chen', detail: 'Full recovery noted without complications.', status: 'Resolved'),
    MedicalRecord(title: 'COVID-19 Bivalent Booster', category: 'Vaccines', date: 'Feb 15, 2023', provider: 'City Health Clinic', detail: 'Dose 4 · Pfizer-BioNTech', status: 'Complete'),
  ];
  @override void dispose() { searchController.dispose(); super.dispose(); }

  Future<void> addRecord() async {
    final title = TextEditingController();
    final provider = TextEditingController();
    final details = TextEditingController();
    String category = 'Visits';
    final saved = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        title: const Text('Add medical record', style: TextStyle(fontWeight: FontWeight.w700)),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Record title', hintText: 'e.g. General check-up')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Category'), items: const [
            DropdownMenuItem(value: 'Visits', child: Text('Visits')),
            DropdownMenuItem(value: 'Surgeries', child: Text('Surgeries')),
            DropdownMenuItem(value: 'Vaccines', child: Text('Vaccines')),
            DropdownMenuItem(value: 'Diagnoses', child: Text('Diagnoses')),
          ], onChanged: (v) => setDialogState(() => category = v ?? 'Visits')),
          const SizedBox(height: 12),
          TextField(controller: provider, decoration: const InputDecoration(labelText: 'Doctor / clinic')),
          const SizedBox(height: 12),
          TextField(controller: details, maxLines: 2, decoration: const InputDecoration(labelText: 'Notes (optional)')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Save record')),
        ],
      ),
    ));
    if (saved == true && title.text.trim().isNotEmpty) {
      setState(() {
        records.insert(0, MedicalRecord(title: title.text.trim(), category: category, date: 'Today', provider: provider.text.trim().isEmpty ? 'Provider not added' : provider.text.trim(), detail: details.text.trim(), status: 'Added'));
        tab = 1; filter = 'All'; query = ''; searchController.clear();
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Medical record added')));
    }
    title.dispose(); provider.dispose(); details.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(records: records, onOpenTimeline: () => setState(() => tab = 1), onAdd: addRecord),
      timelinePage(),
      const MedicationsPage(),
      const DocumentsPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 68,
        titleSpacing: 16,
        title: Row(children: [
          Container(width: 38, height: 38, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: borderColor)), child: const Icon(Icons.health_and_safety_outlined, color: primaryBlue, size: 25)),
          const SizedBox(width: 10),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('My Medical History', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: navy)),
            Text('PERSONAL HEALTH RECORDS', style: TextStyle(fontSize: 9, letterSpacing: 1.05, color: muted, fontWeight: FontWeight.w600)),
          ])),
        ]),
        actions: [
          IconButton(tooltip: 'Notifications', onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You are all caught up!'))), icon: const Icon(Icons.notifications_none_rounded)),
          Padding(padding: const EdgeInsets.only(right: 16), child: CircleAvatar(radius: 17, backgroundColor: const Color(0xFFCBE7F5), child: Text('MM', style: TextStyle(color: primaryBlue, fontWeight: FontWeight.bold, fontSize: 12)))),
        ],
      ),
      body: SafeArea(top: false, child: IndexedStack(index: tab, children: pages)),
      floatingActionButton: tab == 1 ? FloatingActionButton.extended(
        onPressed: addRecord, backgroundColor: primaryBlue, foregroundColor: Colors.white,
        icon: const Icon(Icons.add), label: const Text('Log Record', style: TextStyle(fontWeight: FontWeight.w700)),
      ) : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        backgroundColor: Colors.white, indicatorColor: const Color(0xFFD9F3FF),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.timeline_rounded), label: 'Timeline'),
          NavigationDestination(icon: Icon(Icons.medication_outlined), label: 'Medications'),
          NavigationDestination(icon: Icon(Icons.folder_open_outlined), label: 'Documents'),
        ],
      ),
    );
  }

  Widget timelinePage() {
    final filtered = records.where((r) {
      final matchesFilter = filter == 'All' || r.category == filter;
      final text = '${r.title} ${r.provider} ${r.detail} ${r.category}'.toLowerCase();
      return matchesFilter && text.contains(query.toLowerCase());
    }).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 2, 16, 12), child: Column(children: [
        Row(children: [
          Expanded(child: TextField(controller: searchController, onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search diagnoses, procedures, visits...', isDense: true))),
          const SizedBox(width: 8),
          SizedBox(height: 48, child: FilledButton(onPressed: addRecord, style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Icon(Icons.add))),
        ]),
        const SizedBox(height: 12),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: ['All', 'Visits', 'Surgeries', 'Vaccines', 'Diagnoses'].map((f) => Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(label: Text(f == 'All' ? 'All  ${records.length + 9}' : f), selected: filter == f, onSelected: (_) => setState(() => filter = f), selectedColor: primaryBlue, labelStyle: TextStyle(color: filter == f ? Colors.white : navy, fontWeight: FontWeight.w600), backgroundColor: const Color(0xFFF0F2FF), side: BorderSide.none, showCheckmark: false),
        )).toList())),
      ])),
      Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 90), children: [
        const HealthStatusCard(),
        const SizedBox(height: 22),
        Row(children: [const Icon(Icons.calendar_month, color: primaryBlue), const SizedBox(width: 8), const Text('HEALTH TIMELINE', style: TextStyle(color: primaryBlue, fontWeight: FontWeight.w800, letterSpacing: 1)), const Spacer(), Text('${filtered.length} records', style: const TextStyle(color: muted, fontSize: 12))]),
        const SizedBox(height: 12),
        if (filtered.isEmpty) const EmptyState(title: 'No records found', subtitle: 'Try another search or category filter.'),
        ...filtered.map((r) => RecordCard(record: r)),
        const SizedBox(height: 8),
        const Text('Your records stay organized in one place.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 12)),
      ])),
    ]);
  }
}

class HealthStatusCard extends StatelessWidget {
  const HealthStatusCard({super.key});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(20)),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('HEALTH JOURNEY HEALTHSPAN', style: TextStyle(fontSize: 10, color: primaryBlue, letterSpacing: .7, fontWeight: FontWeight.w800)),
        SizedBox(height: 6), Text('Care continuity: looking good', style: TextStyle(fontSize: 16, color: navy, fontWeight: FontWeight.w800)),
        SizedBox(height: 5), Text('Keep your visits, medicines, and reports together.', style: TextStyle(fontSize: 12, color: muted)),
      ])),
      const SizedBox(width: 10),
      Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0xFF00855B), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.verified_outlined, color: Colors.white, size: 26)),
    ]),
  );
}

class RecordCard extends StatelessWidget {
  const RecordCard({super.key, required this.record});
  final MedicalRecord record;
  @override Widget build(BuildContext context) {
    final color = record.category == 'Vaccines' ? const Color(0xFFB9F6D8) : record.category == 'Surgeries' ? const Color(0xFFFFE0DE) : const Color(0xFFD4EAFE);
    final icon = record.category == 'Vaccines' ? Icons.vaccines_outlined : record.category == 'Surgeries' ? Icons.medical_services_outlined : record.category == 'Diagnoses' ? Icons.monitor_heart_outlined : Icons.favorite_border_rounded;
    return Padding(padding: const EdgeInsets.only(top: 10), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 28, height: 28, margin: const EdgeInsets.only(top: 12, right: 8), decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: borderColor)), child: Icon(icon, size: 15, color: primaryBlue)),
      Expanded(child: Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: borderColor)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(record.date, style: const TextStyle(color: primaryBlue, fontSize: 11, fontWeight: FontWeight.w700))), Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)), child: Text(record.category, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: navy)))]),
        const SizedBox(height: 8),
        Text(record.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: navy)),
        const SizedBox(height: 7),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.local_hospital_outlined, size: 16, color: muted), const SizedBox(width: 6), Expanded(child: Text(record.provider, style: const TextStyle(fontSize: 12, color: muted)))]),
        if (record.detail.isNotEmpty) ...[
          const SizedBox(height: 12),
          Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(12)), child: Text(record.detail, style: const TextStyle(fontSize: 12, color: navy, height: 1.45))),
        ],
        if (record.status.isNotEmpty) ...[const SizedBox(height: 10), Row(children: [const Icon(Icons.check_circle_outline, size: 15, color: Color(0xFF00855B)), const SizedBox(width: 5), Text(record.status, style: const TextStyle(fontSize: 11, color: Color(0xFF00734F), fontWeight: FontWeight.w700))])],
      ]))),
    ]));
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.records, required this.onOpenTimeline, required this.onAdd});
  final List<MedicalRecord> records; final VoidCallback onOpenTimeline, onAdd;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF006194), Color(0xFF0088B8)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('YOUR PERSONAL HEALTH SPACE', style: TextStyle(color: Color(0xFFD9F5FF), fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12), const Text('Hello, Muhammad Mateen', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8), const Text('Your medical history, all in one place.', style: TextStyle(color: Colors.white, fontSize: 13)),
      const SizedBox(height: 20), Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: onOpenTimeline, icon: const Icon(Icons.timeline), label: const Text('View timeline'), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70)))),
        const SizedBox(width: 10), Expanded(child: FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: const Text('Add record'), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: primaryBlue))),
      ]),
    ]),
    const SizedBox(height: 20),
    const Text('HEALTH OVERVIEW', style: TextStyle(fontSize: 12, letterSpacing: 1, color: muted, fontWeight: FontWeight.w800)),
    const SizedBox(height: 10),
    Row(children: [
      Expanded(child: StatCard(icon: Icons.folder_copy_outlined, value: '${records.length}', label: 'Records', color: primaryBlue)),
      const SizedBox(width: 10), const Expanded(child: StatCard(icon: Icons.medication_outlined, value: '2', label: 'Medications', color: Color(0xFF00855B))),
    ]),
    const SizedBox(height: 10),
    Row(children: [
      const Expanded(child: StatCard(icon: Icons.event_available_outlined, value: '1', label: 'Upcoming visit', color: Color(0xFFB77900))),
      const SizedBox(width: 10), const Expanded(child: StatCard(icon: Icons.description_outlined, value: '4', label: 'Documents', color: Color(0xFF7654B5))),
    ]),
    const SizedBox(height: 24),
    Row(children: [const Expanded(child: Text('Recent activity', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: navy))), TextButton(onPressed: onOpenTimeline, child: const Text('See all'))]),
    ...records.take(3).map((r) => RecordCard(record: r)),
    const SizedBox(height: 20),
    const Text('Tip: Keep your latest reports and prescriptions updated for easier appointments.', style: TextStyle(color: muted, fontSize: 12, height: 1.5)),
  ]);
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.icon, required this.value, required this.label, required this.color});
  final IconData icon; final String value, label; final Color color;
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: borderColor)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Icon(icon, color: color, size: 23), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 2), Text(label, style: const TextStyle(fontSize: 12, color: muted)),
  ]));
}

class MedicationsPage extends StatelessWidget {
  const MedicationsPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Medications', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: navy)),
    const SizedBox(height: 6), const Text('A simple overview of your current medicines.', style: TextStyle(color: muted)),
    const SizedBox(height: 20),
    const MedicationCard(name: 'Vitamin D3', dosage: '1000 IU · Once daily', note: 'Take with a meal', icon: Icons.wb_sunny_outlined, color: Color(0xFFFFF0C2)),
    const MedicationCard(name: 'Multivitamin', dosage: '1 tablet · Once daily', note: 'Daily supplement', icon: Icons.medication_outlined, color: Color(0xFFD7F6E7)),
    const SizedBox(height: 14),
    Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFFFF5DB), borderRadius: BorderRadius.circular(14)), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, color: Color(0xFF946200)), SizedBox(width: 10), Expanded(child: Text('Demo information only. Always follow your healthcare professional’s instructions.', style: TextStyle(fontSize: 12, color: navy, height: 1.4)))])),
  ]);
}

class MedicationCard extends StatelessWidget {
  const MedicationCard({super.key, required this.name, required this.dosage, required this.note, required this.icon, required this.color});
  final String name, dosage, note; final IconData icon; final Color color;
  @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: borderColor), borderRadius: BorderRadius.circular(18)), child: Row(children: [
    Container(width: 48, height: 48, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: navy)),
    const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 4), Text(dosage, style: const TextStyle(fontSize: 12, color: muted)), const SizedBox(height: 5), Text(note, style: const TextStyle(fontSize: 11, color: Color(0xFF00855B), fontWeight: FontWeight.w700))])),
    const Icon(Icons.chevron_right, color: muted),
  ]));
}

class DocumentsPage extends StatelessWidget {
  const DocumentsPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Documents', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: navy)),
    const SizedBox(height: 6), const Text('Keep important health files easy to find.', style: TextStyle(color: muted)),
    const SizedBox(height: 20),
    const DocumentCard(title: 'Cardiology visit summary', type: 'Visit summary · PDF', date: 'Oct 18, 2024', icon: Icons.description_outlined),
    const DocumentCard(title: 'Vaccination record', type: 'Immunization · PDF', date: 'Aug 04, 2024', icon: Icons.verified_user_outlined),
    const DocumentCard(title: 'Skin screening notes', type: 'Clinical notes · PDF', date: 'May 12, 2024', icon: Icons.article_outlined),
    const DocumentCard(title: 'Discharge instructions', type: 'Hospital document · PDF', date: 'Nov 20, 2023', icon: Icons.local_hospital_outlined),
    const SizedBox(height: 12), const EmptyState(title: 'Document preview demo', subtitle: 'These are sample document entries. File upload can be added next.'),
  ]);
}

class DocumentCard extends StatelessWidget {
  const DocumentCard({super.key, required this.title, required this.type, required this.date, required this.icon});
  final String title, type, date; final IconData icon;
  @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: borderColor)), child: Row(children: [
    Container(width: 44, height: 44, decoration: BoxDecoration(color: paleBlue, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: primaryBlue)),
    const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: navy)), const SizedBox(height: 4), Text(type, style: const TextStyle(fontSize: 12, color: muted)), const SizedBox(height: 4), Text(date, style: const TextStyle(fontSize: 11, color: primaryBlue))])),
    const Icon(Icons.more_horiz, color: muted),
  ]));
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.title, required this.subtitle});
  final String title, subtitle;
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: borderColor), borderRadius: BorderRadius.circular(18)), child: Column(children: [const Icon(Icons.search_off_outlined, color: muted, size: 32), const SizedBox(height: 10), Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 5), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: muted))]));
}
