package com.example.mateen_medical_history

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
