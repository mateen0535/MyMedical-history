@echo off
setlocal
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found. Install Flutter and add flutter\bin to PATH first.
  pause
  exit /b 1
)
flutter doctor
if errorlevel 1 echo Please review the Flutter doctor output above.
flutter create . --platforms=android
if errorlevel 1 goto failed
flutter pub get
if errorlevel 1 goto failed
echo.
echo Setup complete. Run: flutter run
pause
exit /b 0
:failed
echo Setup failed. Please review the command output above.
pause
exit /b 1
